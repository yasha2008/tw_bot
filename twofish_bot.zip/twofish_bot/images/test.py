from PIL import Image, ImageDraw, ImageFont

image = Image.open("log.png")

# Создание объекта ImageDraw
draw = ImageDraw.Draw(image)
rank = Image.open('0.png')

csgo = Image.open('csgo_prime_new.png')

print(rank.size)
rank = rank.resize((150, 60))
csgo = csgo.resize((40, 40))

        # Установка шрифта
game_font = ImageFont.truetype("SFPRODISPLAYREGULAR.OTF", 23)
id_font = ImageFont.truetype("SFPRODISPLAYREGULAR.OTF", 40)
level_font = ImageFont.truetype("SFPRODISPLAYREGULAR.OTF", 30)

        # Нанесение текста на изображение
        # draw.text((400, 410), "csgo non prime", font=font) # игра
draw.text((235, 210), 'Есть', font=level_font)  # id
draw.text((480, 210), '12$', font=level_font)  # id
draw.text((720, 210), '12:22', font=level_font)  # id

draw.text((235, 400), '10$', font=level_font)  # id

image.paste(rank, (440, 390))

image.paste(csgo, (700, 410))

#draw.text((124, 452), '11', font=level_font)  # уровень

#draw.text((100, 318), 'Limit', font=level_font)  # Статус

#draw.text((360, 320), '100$', font=level_font)  # Инвентарь

# Сохранение изображения с текстом
image.save("image_with_text.png")