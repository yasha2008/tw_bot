import time

import panel.methods as methods
import bot_misc.config as cfg
import database
from main import send_log_photo
from PIL import Image, ImageDraw, ImageFont
import os


def start_stuk():
    token = methods.login_to_panel(cfg.panel_username, cfg.panel_password)
    print(token)
    while True:
        try:
            last_log = methods.get_last_log(token)
            #print(last_log)
            if not database.Accounts.select().where(database.Accounts.id == last_log.get('id')).exists():
                #print('Нет в отстуке')
                info = database.Users.select().where(database.Users.link.contains(last_log.get('link')))[0]
                send_log_photo(last_log, create_log_image(last_log),info.username)
                database.Accounts.create(id=last_log.get('id'), user_id=info.user_id)

                if last_log.get('type') == 'log':
                    database.Users.update(logs=info.logs + 1).where(database.Users.user_id == info.user_id).execute()

                else:
                    database.Users.update(mafiles=info.logs + 1).where(database.Users.user_id == info.user_id).execute()

            time.sleep(10)
        except Exception as e:
            #print(e.with_traceback)
            time.sleep(10)
            continue




def create_log_image(log_info):
    if log_info.get('type') == 'log':
        # Открытие изображения
        #print('Тип', log_info.get('type'))
        rank = Image.open(os.getcwd() + f'/images/{log_info.get("csgoRank")}.png')
        rank = rank.resize((150, 60))
        image = Image.open(os.getcwd() + "/images/log.png")

        # Создание объекта ImageDraw
        draw = ImageDraw.Draw(image)

        level_font = ImageFont.truetype(os.getcwd() + "/images/SFPRODISPLAYREGULAR.OTF", 30)

        draw.text((235, 210), str(log_info.get('status')), font=level_font)  # id
        draw.text((480, 210), str(log_info.get('inventory_price')), font=level_font)  # id

        localtime = time.localtime(time.time())
        current_time = time.strftime("%H:%M:%S", localtime)

        draw.text((700, 210), current_time, font=level_font)  # id

        draw.text((235, 400), str(log_info.get('balance')), font=level_font)  # id

        image.paste(rank, (440, 390))

        game_cord = 700

        for i in log_info.get('games'):
            if 'png' in i or 'jpg' in i:
                game = Image.open(os.getcwd() + '/images/' + i)
                game = game.resize((40,40))
                image.paste(game, (game_cord, 410))
                game_cord += 60

        # Сохранение изображения с текстом
        image.save(os.getcwd() + f"/images/{log_info.get('id')}.png")

    elif log_info.get('type') == 'mafile':
        #print('Тип', log_info.get('type'))
        image1 = Image.open(os.getcwd() + "/images/mafile.png")

        # Создание объекта ImageDraw
        draw = ImageDraw.Draw(image1)

        # Установка шрифта
        id_font = ImageFont.truetype(os.getcwd() + "/images/SFPRODISPLAYREGULAR.OTF", 33)
        level_font = ImageFont.truetype(os.getcwd() + "/images/SFPRODISPLAYREGULAR.OTF", 35)

        localtime = time.localtime(time.time())

        current_time = time.strftime("%H:%M:%S", localtime)

        draw.text((360, 230), current_time, font=id_font)  # id

        draw.text((140, 230), log_info.get('balance'), font=level_font)  # inv

        image1.save(os.getcwd() + f"/images/{log_info.get('id')}.png")

    return os.getcwd() + f"/images/{log_info.get('id')}.png"

# threading.Thread(target=
#                 send_log_photo, args=(create_log_image({'id': '#259340', 'link': 'https://steancommunitliy.ru/profiles/123123123', 'balance': '0$', 'status': 'Limited', 'level': '0', 'games': 'csgo no prime', 'type': 'mafile'}), 1896766219)).start()
