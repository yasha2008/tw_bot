from peewee import *
from playhouse.sqliteq import SqliteQueueDatabase

db = SqliteQueueDatabase("by002.db")

class Users(Model):
    user_id = BigIntegerField(default=0)
    username = TextField(default="")
    verifed = BooleanField(default=False)
    decline = BooleanField(default=False)
    link = TextField(default="")
    balance = IntegerField(default=0)
    logs = IntegerField(default=0)
    mafiles = IntegerField(default=0)
    domains = TextField(default='free_link')
    lzt = TextField(default='')

    class Meta:
        db_table = "Users"
        database = db


class Accounts(Model):
    id = TextField(default='')
    user_id = BigIntegerField(default=0)

    class Meta:
        db_table = "Accounts"
        database = db


class Domains(Model):
    name = TextField()

    class Meta:
        db_table = "Domains"
        database = db


class Templates(Model):
    button_name = TextField()
    id = IntegerField

    class Meta:
        db_table = "Templates"
        database = db

def connect():
    db.connect()
    Users.create_table()
    Accounts.create_table()
    Domains.create_table()
    Templates.create_table()
