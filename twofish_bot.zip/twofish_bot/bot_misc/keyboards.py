from telebot import types

queue_ = types.InlineKeyboardMarkup()
queue_.add(
    types.InlineKeyboardButton(text="Подать заявку", callback_data='queue')
)

domainTypes = types.InlineKeyboardMarkup(row_width=1)
domainTypes.add(
    types.InlineKeyboardButton(text="fSport", callback_data='domain_41474'),
    #types.InlineKeyboardButton(text="Дайвинчик", callback_data='domain_39387'),
    #types.InlineKeyboardButton(text="Профиль Choker", callback_data='domain_24347'),
    #types.InlineKeyboardButton(text="Трейд", callback_data='domain_39387'),
)

def get_user_menu(is_teacher): #type: ignore
    menuUser = types.ReplyKeyboardMarkup(row_width=3, resize_keyboard=True)
    return menuUser.add("👤Профиль").add("🌐Получить ссылку", "📲Статистика").add("🧑‍💻Поддержка", "✅Чаты и Инфа")

profile_kb = types.InlineKeyboardMarkup(row_width=1)
profile_kb.add(types.InlineKeyboardButton(text='💸Заказать выплату', callback_data='create_payment_ticket'))

chats = types.InlineKeyboardMarkup()
chats.add(
   # types.InlineKeyboardButton(text='ℹ️ Инфа', url='https://t.me/+nNB-CxC03A02MjRi'),
    types.InlineKeyboardButton(text='✅ Чат воркеров', url='https://t.me/+KjgSwrONjdMyZjBi'),
    types.InlineKeyboardButton(text='🛎 Отстук', url='https://t.me/+buIBTQpNQnw1ZTVi'),
)

support = types.InlineKeyboardMarkup()
support.add(
    types.InlineKeyboardButton(text="Arxteryx", url='https://t.me/Arxteryx')
)
#admin

admin_kb = types.InlineKeyboardMarkup(row_width=2)
admin_kb.add(
    types.InlineKeyboardButton('✉️Рассылка',callback_data='message'),
    types.InlineKeyboardButton('♻️Стереть линки к хуям', callback_data='clear_links'),
    types.InlineKeyboardButton('✅Начислить балик', callback_data='balance_plus'),
    types.InlineKeyboardButton('Найти юзера по id лога', callback_data='find_user'),
    types.InlineKeyboardButton('Добавить домен', callback_data='admadddomain'),
    types.InlineKeyboardButton('Добавить шаблон', callback_data='admaddshab'),
    types.InlineKeyboardButton('Назад', callback_data='menu')
)