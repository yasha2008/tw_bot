domain_name = ['https://go2cup.com/'] # на свой меняй

panel_username = 'arcteryxxxx'      # ну тут понятно
panel_password = 'oSxkWi99'  # ну тут понятно

payments = 1269206494 # chat id куда заявки на выплату будут лететь
logs = -1001977898074
vyplats = 1

bot_token = '6567733620:AAFL57RPFt-_YpuS1kw1MPOx9Nz7QqN1fD4' # токен бота
admins = [1269206494, 1896766219] # чат id админов